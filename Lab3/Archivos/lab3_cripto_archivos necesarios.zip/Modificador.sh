#!/bin/bash

original_file="rockyou.txt"
modified_file="rockyou_mod.dic"

sed '/^[0-9]/d; s/^\(.\)\(.*\)/\U\1\E\2/' "$original_file" | sed 's/$/0/' > "$modified_file"

line_count=$(wc -l < "$modified_file")

echo "La cantidad de contraseñas en el diccionario modificado es: $line_count"
